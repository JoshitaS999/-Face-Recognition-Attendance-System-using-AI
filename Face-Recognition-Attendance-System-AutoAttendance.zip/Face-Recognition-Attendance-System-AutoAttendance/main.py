import os
import cv2
import numpy as np
import pandas as pd
import json
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, flash, send_from_directory

app = Flask(__name__)
app.secret_key = "replace-this-with-a-random-secret"

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
FACES_DIR = os.path.join(BASE_DIR, "static", "faces")
ATT_DIR = os.path.join(BASE_DIR, "Attendance")
CONFIG_PATH = os.path.join(BASE_DIR, "config.json")
CASCADE_PATH = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"

# ensure folders exist
os.makedirs(FACES_DIR, exist_ok=True)
os.makedirs(ATT_DIR, exist_ok=True)

def load_config():
    if not os.path.isfile(CONFIG_PATH):
        cfg = {"set_login_time": None, "last_checked": None}
        with open(CONFIG_PATH, "w") as f:
            json.dump(cfg, f)
        return cfg
    with open(CONFIG_PATH, "r") as f:
        return json.load(f)

def save_config(cfg):
    with open(CONFIG_PATH, "w") as f:
        json.dump(cfg, f)

def get_registered_users():
    users = []
    if os.path.isdir(FACES_DIR):
        for entry in os.listdir(FACES_DIR):
            if os.path.isdir(os.path.join(FACES_DIR, entry)):
                users.append(entry)
    return sorted(users)

def train_recognizer():
    # Train LBPH recognizer on images in static/faces/<name>/*.jpg
    recognizer = cv2.face.LBPHFaceRecognizer_create()
    faces = []
    labels = []
    label_map = {}
    cur_label = 0
    for person in get_registered_users():
        pdir = os.path.join(FACES_DIR, person)
        for fname in os.listdir(pdir):
            if fname.lower().endswith((".png", ".jpg", ".jpeg")):
                img_path = os.path.join(pdir, fname)
                img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
                if img is None:
                    continue
                faces.append(img)
                labels.append(cur_label)
        label_map[cur_label] = person
        cur_label += 1
    if len(faces) == 0:
        return None, {}
    recognizer.train(faces, np.array(labels))
    return recognizer, label_map

def write_attendance_row(name, timestr):
    today = datetime.now().strftime("%Y-%m-%d")
    out_path = os.path.join(ATT_DIR, f"Attendance_{today}.csv")
    exists = os.path.isfile(out_path)
    df = pd.DataFrame([[name, today, timestr, ""]], columns=["Name","Date","Time","Status"])
    if exists:
        df_old = pd.read_csv(out_path)
        df = pd.concat([df_old, df], ignore_index=True)
    df.to_csv(out_path, index=False)
    return out_path

def get_todays_attendance_df():
    today = datetime.now().strftime("%Y-%m-%d")
    path = os.path.join(ATT_DIR, f"Attendance_{today}.csv")
    if os.path.isfile(path):
        try:
            df = pd.read_csv(path)
            # normalize columns
            for col in ["Name","Date","Time","Status"]:
                if col not in df.columns:
                    df[col] = ""
            return df
        except Exception:
            pass
    # return empty df
    return pd.DataFrame(columns=["Name","Date","Time","Status"])

@app.route('/static/<path:filename>')
def static_serve(filename):
    return send_from_directory(os.path.join(BASE_DIR, "static"), filename)

@app.route('/')
def index():
    cfg = load_config()
    attendance = get_todays_attendance_df()
    users = get_registered_users()
    return render_template("index.html",
                           attendance_set_login_time=cfg.get("set_login_time"),
                           attendance_last_checked=cfg.get("last_checked"),
                           attendance_df=attendance.to_dict(orient="records"),
                           users=users)

@app.route('/set_login_time', methods=['POST'])
def set_login_time():
    t = request.form.get("login_time")
    if not t:
        flash("Please provide a time.", "warning")
        return redirect(url_for("index"))
    cfg = load_config()
    cfg["set_login_time"] = t  # expected "HH:MM"
    cfg["last_checked"] = None
    save_config(cfg)
    flash(f"Login cutoff saved: {t}", "success")
    return redirect(url_for("index"))

@app.route('/add_user', methods=['POST'])
def add_user():
    name = request.form.get("name")
    if not name:
        flash("Please enter a name.", "warning")
        return redirect(url_for("index"))
    name = name.strip().replace(" ", "_")
    user_dir = os.path.join(FACES_DIR, name)
    os.makedirs(user_dir, exist_ok=True)
    # capture 30 images from webcam for the new user
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        flash("Cannot access webcam. Run the server on a machine with a webcam.", "danger")
        return redirect(url_for("index"))
    detector = cv2.CascadeClassifier(CASCADE_PATH)
    count = 0
    flash("Capturing face samples. Look at the camera...", "info")
    while True:
        ret, frame = cap.read()
        if not ret:
            break
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = detector.detectMultiScale(gray, 1.3, 5)
        for (x,y,w,h) in faces:
            count += 1
            face_img = gray[y:y+h, x:x+w]
            file_path = os.path.join(user_dir, f"{name}_{count}.jpg")
            cv2.imwrite(file_path, face_img)
            # draw rectangle for feedback
            cv2.rectangle(frame, (x,y), (x+w,y+h), (0,255,0), 2)
        cv2.imshow("Adding User - Press q to stop", frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
        if count >= 30:
            break
    cap.release()
    cv2.destroyAllWindows()
    flash(f"Captured {count} samples for {name}.", "success")
    return redirect(url_for("index"))

@app.route('/start_recognition', methods=['POST'])
def start_recognition():
    # Train recognizer
    recognizer, label_map = train_recognizer()
    if recognizer is None:
        flash("No registered users found. Add users first.", "warning")
        return redirect(url_for("index"))
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        flash("Cannot access webcam. Run server on machine with webcam.", "danger")
        return redirect(url_for("index"))
    detector = cv2.CascadeClassifier(CASCADE_PATH)
    seen = {}  # name -> earliest time str
    # run for a duration (optional form param)
    duration = int(request.form.get("duration", 20))
    start_time = datetime.now()
    flash("Recognition started. Press 'q' in the preview window to stop early.", "info")
    while (datetime.now() - start_time).seconds < duration:
        ret, frame = cap.read()
        if not ret:
            break
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = detector.detectMultiScale(gray, 1.2, 5)
        for (x,y,w,h) in faces:
            face = gray[y:y+h, x:x+w]
            try:
                label, conf = recognizer.predict(face)
            except Exception:
                continue
            name = label_map.get(label, "Unknown")
            timestr = datetime.now().strftime("%H:%M:%S")
            if name != "Unknown":
                # record earliest seen time
                if name not in seen:
                    seen[name] = timestr
                # feedback rectangle
                cv2.rectangle(frame, (x,y), (x+w,y+h), (0,255,0), 2)
                cv2.putText(frame, f"{name}", (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0,255,0), 2)
            else:
                cv2.rectangle(frame, (x,y), (x+w,y+h), (0,0,255), 2)
                cv2.putText(frame, "Unknown", (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0,0,255), 2)
        cv2.imshow("Recognition - press q to stop", frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    cap.release()
    cv2.destroyAllWindows()
    # write seen users to today's attendance (earliest time)
    for name, timestr in seen.items():
        write_attendance_row(name, timestr)
    if seen:
        flash(f"Recorded {len(seen)} attendance entries.", "success")
    else:
        flash("No faces recognized during the session.", "warning")
    return redirect(url_for("index"))

@app.route('/check_attendance', methods=['POST'])
def check_attendance():
    cfg = load_config()
    if not cfg.get("set_login_time"):
        flash("Set login cutoff time first.", "warning")
        return redirect(url_for("index"))
    cutoff_str = cfg.get("set_login_time")
    try:
        cutoff = datetime.strptime(cutoff_str, "%H:%M").time()
    except Exception:
        flash("Invalid cutoff format in config. Reset it.", "danger")
        return redirect(url_for("index"))
    df = get_todays_attendance_df()
    # ensure columns
    for col in ["Name","Date","Time","Status"]:
        if col not in df.columns:
            df[col] = ""
    # map names to earliest time
    name_to_time = {}
    for idx, row in df.iterrows():
        name = str(row.get("Name","")).strip()
        timestr = str(row.get("Time","")).strip()
        if name and timestr:
            try:
                t = datetime.strptime(timestr, "%H:%M:%S").time()
                if name not in name_to_time or t < name_to_time[name]:
                    name_to_time[name] = t
            except Exception:
                continue
    users = get_registered_users()
    today = datetime.now().strftime("%Y-%m-%d")
    # ensure entries for all users
    for u in users:
        if u not in name_to_time:
            # add absent row
            df = pd.concat([df, pd.DataFrame([{"Name":u,"Date":today,"Time":"","Status":"Absent"}])], ignore_index=True)
        else:
            t = name_to_time[u]
            status = "Present" if t <= cutoff else "Late"
            # find first row index for user and update
            mask = df["Name"].astype(str).str.strip() == u
            if not mask.any():
                df = pd.concat([df, pd.DataFrame([{"Name":u,"Date":today,"Time":t.strftime("%H:%M:%S"),"Status":status}])], ignore_index=True)
            else:
                first_idx = df[mask].index[0]
                df.at[first_idx,"Status"] = status
                df.at[first_idx,"Date"] = today
                if not df.at[first_idx,"Time"]:
                    df.at[first_idx,"Time"] = t.strftime("%H:%M:%S")
    out_path = os.path.join(ATT_DIR, f"Attendance_{today}.csv")
    df.to_csv(out_path, index=False)
    cfg["last_checked"] = datetime.now().isoformat()
    save_config(cfg)
    flash(f"Attendance updated and saved to {out_path}.", "success")
    return redirect(url_for("index"))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
