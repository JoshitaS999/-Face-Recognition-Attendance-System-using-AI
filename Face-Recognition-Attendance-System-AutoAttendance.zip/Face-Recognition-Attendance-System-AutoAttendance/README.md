
# Face Recognition Attendance System (Auto Attendance)

This project is a self-contained Flask app that supports:
- Adding users (capture face samples via webcam)
- Training & recognizing faces using LBPH
- Recording attendance to CSV files (Attendance/Attendance_<YYYY-MM-DD>.csv)
- Setting a login cutoff time via web UI
- Checking attendance to mark Present / Late / Absent and display on dashboard

## How to run (local machine with webcam)
1. Unzip the project
2. Create a Python virtual environment (recommended)
3. Install requirements:
   pip install -r requirements.txt
4. Run the app:
   python main.py
5. Open http://127.0.0.1:5000 in your browser
6. Use "Add User" to capture samples (a preview window opens; press 'q' to stop early)
7. Use "Take Attendance" to start recognition (opens preview; recognized users will be recorded)
8. Set a login cutoff time and press "Check Attendance" after the cutoff to mark Present/Late/Absent

Notes:
- The webcam preview windows are opened by OpenCV on the machine running the Flask server.
- This project is a best-effort reconstruction for your original app and includes the requested login-time features.
